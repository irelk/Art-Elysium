function initData() {
  jimData.variables["Email"] = "";
  jimData.variables["Position"] = "1";
  jimData.variables["Username"] = "";
  jimData.variables["FirstName"] = "";
  jimData.variables["LastName"] = "";
  jimData.variables["Password"] = "";
  jimData.datamasters["Sign Up"] = [
    {
      "id": 1,
      "datamaster": "Sign Up",
      "userdata": {
        "First Name": "sample text",
        "Last Name": "sample text",
        "Username": "sample text",
        "Email": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 2,
      "datamaster": "Sign Up",
      "userdata": {
        "First Name": "sample text",
        "Last Name": "sample text",
        "Username": "sample text",
        "Email": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "Sign Up",
      "userdata": {
        "First Name": "sample text",
        "Last Name": "sample text",
        "Username": "sample text",
        "Email": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 4,
      "datamaster": "Sign Up",
      "userdata": {
        "First Name": "sample text",
        "Last Name": "sample text",
        "Username": "sample text",
        "Email": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 5,
      "datamaster": "Sign Up",
      "userdata": {
        "First Name": "sample text",
        "Last Name": "sample text",
        "Username": "sample text",
        "Email": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 6,
      "datamaster": "Sign Up",
      "userdata": {
        "First Name": "sample text",
        "Last Name": "sample text",
        "Username": "sample text",
        "Email": "sample text",
        "Password": "sample text"
      }
    }
  ];

  jimData.datamasters["Users"] = [
    {
      "id": 1,
      "datamaster": "Users",
      "userdata": {
        "Usename": "admin",
        "Password": "admin"
      }
    },
    {
      "id": 2,
      "datamaster": "Users",
      "userdata": {
        "Usename": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "Users",
      "userdata": {
        "Usename": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 4,
      "datamaster": "Users",
      "userdata": {
        "Usename": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 5,
      "datamaster": "Users",
      "userdata": {
        "Usename": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 6,
      "datamaster": "Users",
      "userdata": {
        "Usename": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 7,
      "datamaster": "Users",
      "userdata": {
        "Usename": "sample text",
        "Password": "sample text"
      }
    }
  ];

  jimData.isInitialized = true;
}